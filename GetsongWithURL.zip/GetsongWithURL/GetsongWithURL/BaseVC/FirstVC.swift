//
//  FirstVC.swift
//  GetsongWithURL
//
//  Created by JigneshRajora on 26/11/18.
//  Copyright © 2018 JigneshRajora. All rights reserved.

import UIKit
import AVFoundation
import AVKit
import EZAudio

var playVC = AVPlayerViewController()
var player:AVPlayer?
var playerItem:AVPlayerItem?
var songs:[[String]] = [[]]
var i:Int = 0
var chacked = false

class FirstVC: UIViewController,UINavigationControllerDelegate,EZAudioPlayerDelegate{

    @IBOutlet weak var BtnPlay: UIButton!
    @IBOutlet weak var BtnPause: UIButton!
    @IBOutlet weak var BtnPrevious: UIButton!
    @IBOutlet weak var BtnNext: UIButton!
    @IBOutlet weak var SOngVolume: UISlider!
    @IBOutlet weak var SongSlider: UISlider!
    @IBOutlet var EqualiserView: UIView!
    @IBOutlet weak var BtnEQ: UIButton!
    @IBOutlet weak var SlideBass: UISlider!
    @IBOutlet weak var SlideBaritone: UISlider!
    @IBOutlet weak var SlideTreble: UISlider!
    @IBOutlet weak var Imgbackgrnd: UIImageView!
    
    @IBOutlet weak var Songs: EZAudioPlotGL!
    
    var urls = ["https://s3.us-east-2.amazonaws.com/crypticpoint.projects.upload/sauteez/media/video_songs/MED154280487760801/_1542804754.mp3","https://s3.us-east-2.amazonaws.com/crypticpoint.projects.upload/sauteez/media/_1542806878.mp3",
                "https://s3.us-east-2.amazonaws.com/crypticpoint.projects.upload/sauteez/media/video_songs/MED154280464444613/_1542804151.mp3"]
   
    var thisSong = 0
    var audioStuffed = false
    var playerLayer = AVPlayerLayer(player: player)
    var AudioEngine:AVAudioEngine = AVAudioEngine()
    var Equalizer:AVAudioUnitEQ!
    var AudioPlayerNode:AVAudioPlayerNode = AVAudioPlayerNode()
    var AudioFile:AVAudioFile!
    var AudioFiles: EZAudioFile?
    override func viewDidLoad() {
        super.viewDidLoad()
        EqualiserView.isHidden = true
        SOngVolume.isHidden = true
        Imgbackgrnd.image = UIImage(named: "Imusicana_music_player")
        let url = urls[i]
        audioStuffed = false
        songs.append(urls)
        print(songs)
        print(url)
        
        // MARKS:-- For Create view for Song player
        guard let urlr = URL.init(string: url) else { return }
        playerItem = AVPlayerItem.init(url: urlr)
        player = AVPlayer(playerItem: playerItem!)
        playerLayer.frame = CGRect(x: 0, y: 0, width: 10, height: 10)
        view.layer.addSublayer(playerLayer)
        do{
            AudioFile = try AVAudioFile(forReading: urlr)
            try AudioEngine.start()
            AudioPlayerNode.scheduleFile(AudioFile, at: nil, completionHandler: nil)
        }catch{
            print("Error is occuring ")
        }
        //MARKS:-- Using For Slider in FirstVC
        let duration : CMTime = (playerItem?.asset.duration)!
        let seconds : Float64 = CMTimeGetSeconds(duration)
        SongSlider.maximumValue = Float(seconds)
        SongSlider.isContinuous = true
        player!.addPeriodicTimeObserver(forInterval: CMTimeMakeWithSeconds(1, preferredTimescale: 1), queue: DispatchQueue.main) { (CMTime) -> Void in
            if player!.currentItem?.status == .readyToPlay {
                let time : Float64 = CMTimeGetSeconds(player!.currentTime());
                self.SongSlider!.value = Float ( time );
            }
        }
    }
    func EQlizers(){
        Equalizer = AVAudioUnitEQ(numberOfBands: 3)
        AudioEngine.attach(AudioPlayerNode)
        AudioEngine.attach(Equalizer)
        var bands = Equalizer.bands
        let freqs = [60, 230, 910]
        AudioEngine.connect(AudioPlayerNode,to: Equalizer,format: nil)
        AudioEngine.connect(Equalizer, to: AudioEngine.outputNode, format: nil)
        for j in 0...(bands.count - 1) {
            bands[j].frequency = Float(freqs[i])
            bands[j].bypass = false
            bands[j].filterType = .parametric
        }
        bands[0].gain = 60.0
        bands[0].filterType = .lowShelf
        bands[1].gain = 200.0
        bands[1].filterType = .highShelf
        bands[2].gain = 900.0
        bands[2].filterType = .lowShelf
        
        bands[0].gain = SlideBass.value
        bands[1].gain = SlideBaritone.value
        
//        highPass.bypass = SlideBass.value
//        highPass.bypass = SlideTreble.value
//        lowPass.bandwidth = SlideBaritone.value
//        bands[3].gain = 10.0
//        bands[3].filterType = .highShelf
//        bands[4].gain = 10.0
//        bands[4].filterType = .highShelf
    }
    func images(){
        if thisSong == 0 {
            Imgbackgrnd.image = UIImage(named: "Imusicana_music_player")
        }else if thisSong == 1{
            Imgbackgrnd.image = UIImage(named: "2")
        }else if thisSong == 2{
            Imgbackgrnd.image = UIImage(named: "3")
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        NotificationCenter.default.addObserver(self, selector: Selector("finishedPlaying:"), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: playerItem)
    }
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
    }
   @objc func finishedPlaying(myNotification:NSNotification) {
        let stopedPlayerItem: AVPlayerItem = myNotification.object as! AVPlayerItem
        stopedPlayerItem.seek(to: CMTime.zero)
    }
    @IBAction func BtnPlaySong(_ sender: UIButton) {
        let duration : CMTime = (playerItem?.asset.duration)!
        let seconds : Float64 = CMTimeGetSeconds(duration)
        SongSlider.maximumValue = Float(seconds)
        SongSlider.isContinuous = true
     //   SongSlider.addTarget(self, action: #selector(playbackSliderValueChanged(_:)), for: .valueChanged)
        player!.addPeriodicTimeObserver(forInterval: CMTimeMakeWithSeconds(1, preferredTimescale: 1), queue: DispatchQueue.main) { (CMTime) -> Void in
            if player!.currentItem?.status == .readyToPlay {
                let time : Float64 = CMTimeGetSeconds(player!.currentTime());
                self.SongSlider!.value = Float ( time );
            }
        }
        playbackSliderValueChanged(SongSlider)
    }
    func playbackSliderValueChanged(_ playbackSlider:UISlider)
    {
        let seconds : Int64 = Int64(SongSlider.value)
        let targetTime:CMTime = CMTimeMake(value: seconds, timescale: 1)
        
        player!.seek(to: targetTime)
        if player!.rate == 0.0
        {
            player?.play()
        }
    }
    @IBAction func BtnPauseSong(_ sender: UIButton) {
        player!.pause()
    }
    @IBAction func SlideSongVol(_ sender: UISlider) {
        player?.volume = sender.value
    }
    @IBAction func BtnShowVolume(_ sender: UIButton) {
        if SOngVolume.isHidden == true {
            SOngVolume.isHidden = false
        }else{
            SOngVolume.isHidden = true
        }
    }
    @IBAction func BtnPreviousSong(_ sender: UIButton) {
        self.SongSlider.value = 0
        if audioStuffed == false && thisSong != 0
        {
            let geturl = urls[thisSong-1]
            playsong(url: geturl)
            player?.play()
            thisSong -= 1
             images()
            print(thisSong)
            SongSlider.isContinuous = true
            player!.addPeriodicTimeObserver(forInterval: CMTimeMakeWithSeconds(1, preferredTimescale: 1), queue: DispatchQueue.main) { (CMTime) -> Void in
                if player!.currentItem?.status == .readyToPlay {
                    let time : Float64 = CMTimeGetSeconds(player!.currentTime());
                    self.SongSlider!.value = Float ( time );
                }
            }
        }
        else
        {
            print("error")
        }
    }
    @IBAction func BtnNextSong(_ sender: UIButton) {
        self.SongSlider.value = 0
        if audioStuffed == false && thisSong < urls.count-1
        {
            let geturl = urls[thisSong+1]
             playsong(url: geturl)
            player?.play()
            thisSong += 1
            images()
        print(thisSong)
        SongSlider.isContinuous = true
        player!.addPeriodicTimeObserver(forInterval: CMTimeMakeWithSeconds(1, preferredTimescale: 1), queue: DispatchQueue.main) { (CMTime) -> Void in
            if player!.currentItem?.status == .readyToPlay {
                let time : Float64 = CMTimeGetSeconds(player!.currentTime());
                self.SongSlider!.value = Float ( time );
            }
        }
        }
        else
        {
            print("error")
        }
    }
    @IBAction func SongSliders(_ sender: UISlider) {
    playbackSliderValueChanged(SongSlider)
    }
    func playsong(url:String){
    //   self.view.willRemoveSubview(playlayer)
        guard let urlr = URL.init(string: url) else { return }
        playerItem = AVPlayerItem.init(url: urlr)
        player = AVPlayer(playerItem: playerItem!)
        player?.play()
    }
    @IBAction func BtnEQlzr(_ sender: UIButton) {
            if chacked == false{
            chacked = true
            EqualiserView.isHidden = false
            }else {
            chacked = false
            EqualiserView.isHidden = true
        }
    }
    @IBAction func SliderBass(_ sender: UISlider) {
        
        
        
        EQlizers()
    }
    @IBAction func SliderBaritone(_ sender: UISlider) {
    }
    @IBAction func SliderTreble(_ sender: UISlider) {
    EQlizers()
    }
}
//        do {
//
//            if let filepath = Bundle.main.path(forResource: "song", ofType: "mp3") {
//                let filepathURL = NSURL.fileURL(withPath: filepath)
//                AudioFile = try AVAudioFile(forReading: filepathURL)
//                AudioEngine.prepare()
//                try AudioEngine.start()
//                AudioPlayerNode.scheduleFile(AudioFile, at: nil, completionHandler: nil)
//                AudioPlayerNode.play()
//            }
//        } catch{
//            print("Error is occuring...")
//        }
