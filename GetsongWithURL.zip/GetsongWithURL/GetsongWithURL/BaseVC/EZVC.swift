//
//  EZVC.swift
//  GetsongWithURL
//
//  Created by JigneshRajora on 03/12/18.
//  Copyright © 2018 JigneshRajora. All rights reserved.

//import UIKit
//import EZAudio
//
//var AudioFiles: EZAudioFile?
//var audioFile: EZAudioFile?
//var players: EZAudioPlayer?
//
//class EZVC: UIViewController,EZAudioPlayerDelegate{
//
//
//    @IBOutlet weak var audioPlot: EZAudioPlotGL!
//    @IBOutlet weak var filePathLabel: UILabel!
//    @IBOutlet weak var positionSlider: UISlider!
//    @IBOutlet weak var rollingHistorySlider: UISlider!
//    @IBOutlet weak var volumeSlider: UISlider!
//
//    @IBAction func changePlotType(_ sender: Any) {
//
//    }
//
//    @IBAction func changeRollingHistoryLength(_ sender: Any) {
//
//    }
//
//    @IBAction func changeVolume(_ sender: Any) {
//
//    }
//
//    @IBAction func play(_ sender: Any) {
//    
//    }
//
//    @IBAction func seek(toFrame sender: Any) {
//    
//    }
//
//    deinit {
//        NotificationCenter.default.removeObserver(self)
//    }
//    //------------------------------------------------------------------------------
//    // MARK: - Status Bar Style
//    //--------------------------------------------------------------------------
//    override var preferredStatusBarStyle: UIStatusBarStyle {
//        return .lightContent
//    }
//    //------------------------------------------------------------------------------
//    // MARK: - Setup
//    //------------------------------------------------------------------------------
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        //
//        // Setup the AVAudioSession. EZMicrophone will not work properly on iOS
//        // if you don't do this!
//        //
//
//        let session = AVAudioSession.sharedInstance()
//        var error: Error?
//        try? session.setCategory(AVAudioSession.Category.playback, mode: .default, options: .defaultToSpeaker)
//       // try? session.setCategory(AVAudioSession.Category.playback)
//        if error != nil {
//            print("Error setting up audio session category: \(error?.localizedDescription ?? "")")
//        }
//        try? session.setActive(true)
//        if error != nil {
//       drawBufferPlot()
//        print("Error setting up audio session active: \(error?.localizedDescription ?? "")")
//        }
//        //  Converted to Swift 4 by Swiftify v4.1.6836 - https://objectivec2swift.com/
//        audioPlot.backgroundColor = UIColor(red: 0.816, green: 0.349, blue: 0.255, alpha: 1)
//        audioPlot.color = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
//        audioPlot.plotType = EZPlotType.buffer
//        audioPlot.shouldFill = true
//        audioPlot.shouldMirror = true
//
//        print("outputs: \(EZAudioDevice.outputDevices())")
//        //
//        // Create the audio player
//        //
//        players = EZAudioPlayer(delegate: self)
//        players?.shouldLoop = true
//
//        //
//        // Override the output to the speaker
//        //
////        try? session.overrideOutputAudioPort(AVAudioSession.PortOverride)
//        try? session.overrideOutputAudioPort(AVAudioSession.PortOverride.speaker)
//        if error != nil {
//            print("Error overriding output to the speaker: \(error?.localizedDescription ?? "")")
//        }
//
//        rollingHistorySlider.value = Float(audioPlot.rollingHistoryLength())
//
//        //
//        // Listen for EZAudioPlayer notifications
//        //
//        setupNotifications()
//
//        /*
//         Try opening the sample file
//         */
//          openFile(withFilePathURL: URL(fileURLWithPath: "EZAudioFileDelegate"))
//   //     openFile(withFilePathURL:URL(fileURLWithPath:EZAudioFileDelegate))
//
//        
//}
//
//    /*
//     Give the visualization of the current buffer (this is almost exactly the openFrameworks audio input eample)
//     */
//
//    func drawBufferPlot() {
//        audioPlot.plotType = EZPlotType.buffer
//        audioPlot.shouldMirror = false
//        audioPlot.shouldFill = false
//    }
//
//    //------------------------------------------------------------------------------
//    /*
//     Give the classic mirrored, rolling waveform look
//     */
//    func drawRollingPlot() {
//        audioPlot.plotType = EZPlotType.rolling
//        audioPlot.shouldFill = true
//        audioPlot.shouldMirror = true
//    }
//
//    func setupNotifications() {
//        NotificationCenter.default.addObserver(self, selector: #selector(self.audioPlayerDidChangeAudioFile(_:)), name: NSNotification.Name.EZAudioPlayerDidChangeAudioFile, object: players)
//
//        NotificationCenter.default.addObserver(self, selector: #selector(self.audioPlayerDidChangeOutputDevice(_:)), name: NSNotification.Name.EZAudioPlayerDidChangeOutputDevice,object: players)
//        NotificationCenter.default.addObserver(self, selector: #selector(self.audioPlayerDidChangePlayState(_:)), name: NSNotification.Name.EZAudioPlayerDidChangePlayState, object: players)
//    }
//    @objc func audioPlayerDidChangeAudioFile(_ notification: Notification?) {
//        let playersr = notification?.object as? EZAudioPlayer
//        if let aFile = playersr?.audioFile {
//            print("Player changed audio file: \(aFile)")
//        }
//    }
//
//    @objc func audioPlayerDidChangeOutputDevice(_ notification: Notification?) {
//        let playerz = notification?.object as? EZAudioPlayer
//        if let aDevice = playerz?.device {
//            print("Player changed output device: \(aDevice)")
//        }
//    }
//    
//    //------------------------------------------------------------------------------
//    @objc func audioPlayerDidChangePlayState(_ notification: Notification?) {
//        let playerz = notification?.object as? EZAudioPlayer
//        if let aPlaying = playerz?.isPlaying {
//            print(String(format: "Player change play state, isPlaying: %i", aPlaying))
//        }
//    }
//
//    
//    func changePlotType(_ sender: Any?) {
//        let selectedSegment:Int? = (sender as AnyObject).selectedSegmentIndex
//        switch selectedSegment {
//        case 0:
//                drawBufferPlot()
//                break
//        case 1:
//                drawRollingPlot()
//                break
//        default:
//            break
//        }
//    }
//    //------------------------------------------------------------------------------
//    
//    func changeRollingHistoryLength(_ sender: Any?) {
//        let value: Float? = (sender as? UISlider)?.value
//        audioPlot.setRollingHistoryLength(Int32(value ?? 0))
//
//        //        audioPlot.rollingHistoryLength = Int(value ?? 0)
//    }
//    //------------------------------------------------------------------------------
//    func changeVolume(_ sender: Any?) {
//        let value: Float? = (sender as? UISlider)?.value
//        players!.volume = value!
//    }
//    func openFile(withFilePathURL filePathURL: URL?) {
//        //
//        // Create the EZAudioPlayer
//        //
//        audioFile = EZAudioFile(url: filePathURL)
//        
//        //
//        // Update the UI
//        //
//        filePathLabel.text = filePathURL?.lastPathComponent
//        positionSlider.maximumValue = Float((Float(audioFile!.totalFrames) as NSNumber))
//        volumeSlider.value = (players?.volume)!
//
//        //
//        // Plot the whole waveform
//        //
//        audioPlot.plotType = EZPlotType.buffer
//        audioPlot.shouldFill = true
//        audioPlot.shouldMirror = true
//        weak var weakSelf = self
////        audioFile.getWaveformData(withCompletionBlock: { waveformData, length in
////            weakSelf!.audioPlot.updateBuffer(waveformData?[0], withBufferSize: length)})
//        
//        //
//        // Play the audio file
//        //
//        players?.audioFile = audioFile
//    }
//
//    //------------------------------------------------------------------------------
//
//    func play(_ sender: Any?) {
//        if (players?.isPlaying)! {
//           players?.pause()
//        } else {
//            if audioPlot.shouldMirror && (audioPlot.plotType == EZPlotType.buffer){
////            if audioPlot.shouldMirror && (audioPlot.plotType == EZPlotTypeBuffer) {
//                audioPlot.shouldMirror = false
//                audioPlot.shouldFill = false
//            }
//            players?.play()
////            players.play()
//        }
//    }
//    
//    //------------------------------------------------------------------------------
//    func seek(toFrame sender: Any?) {
//        players?.seek(toFrame: (sender as! UISlider).value as? vSInt32)
////        player.seek(toFrame: (sender as? UISlider)?.value as? SInt64)
//    }
//
//    //------------------------------------------------------------------------------
//    // MARK: - EZAudioPlayerDelegate
//    //------------------------------------------------------------------------------
//
//    func audioPlayer(_ audioPlayer: EZAudioPlayer!, playedAudio buffer: UnsafeMutablePointer<UnsafeMutablePointer<Float>?>!, withBufferSize bufferSize: UInt32, withNumberOfChannels numberOfChannels: UInt32, in audioFile: EZAudioFile!) {
//        DispatchQueue.main.async(execute: {
//            weakSelf!.audioPlot.updateBuffer(buffer?[0], withBufferSize: bufferSize)
//        })
//    }
//    func audioPlayer(_ audioPlayer: EZAudioPlayer!, updatedPosition framePosition: Int64, in audioFile: EZAudioFile!) {
//        weak  var weakSelf = DispatchQueue.self
//        if weakSelf!.positionSlider{
//            weakSelf.
//
//        }
//    }
//    func audioPlayer(_ audioPlayer: EZAudioPlayer!, reachedEndOf audioFile: EZAudioFile!) {
//        audioFile: EZAudioFile?)do {
//            weak var weakSelf = self
//            DispatchQueueweakSelfDispatchQueue(execute: {
//                if weakSelf!.positionSlider.isTouchInside {
//                    weakSelf!.positionSlider.value = AVAudioFramePosition
////                        Float(framePosition)
//                }
//            })
//    }
//    //------------------------------------------------------------------------------
//    // MARK: - Utility
//    //-----------------------------------------------------------------------------
//
//    }
//}

// MARK:-- Copy of ObjC File.....

import UIKit
import EZAudio
import AVFoundation

let kAudioFileDefault = Bundle.main.path(forResource: "simple-drum-beat", ofType: "wav")

class EZVC: UIViewController,EZAudioPlayerDelegate {
    
    var audioFile: EZAudioFile?
    var Player: EZAudioPlayer?
    
    @IBOutlet weak var audioPlot: EZAudioPlotGL!
    @IBOutlet weak var filePathLabel: UILabel!
    @IBOutlet weak var positionSlider: UISlider!
    @IBOutlet weak var rollingHistorySlider: UISlider!
    @IBOutlet weak var volumeSlider: UISlider!
    
    //------------------------------------------------------------------------------
    // MARK: - Actions
    @IBAction func changePlotType(_ sender: Any) {
    
    }
    
    @IBAction func changeRollingHistoryLength(_ sender: Any) {
    
    }
    
    @IBAction func changeVolume(_ sender: Any) {
    
    }
    
    @IBAction func play(_ sender: Any) {
    Player?.play()
    }
    
    @IBAction func seek(toFrame sender: Any) {
    }
        deinit {
            NotificationCenter.default.removeObserver(self)
        }
        
    override var preferredStatusBarStyle: UIStatusBarStyle {
            return .lightContent
        }
     override func viewDidLoad() {
            super.viewDidLoad()
            
            let session = AVAudioSession.sharedInstance()
            var error: Error?
            try? session.setCategory(AVAudioSession.Category.playback, mode: .default, policy: .default, options: .default)
        //            try? session.setCategory(AVAuAVAudioSession.Category.playback          if error != nil {
                print("Error setting up audio session category: \(error?.localizedDescription ?? "")")
            }
            try? session.setActive(true)
            if error != nil {
                print("Error setting up audio session active: \(error?.localizedDescription ?? "")")
            }
            audioPlot.backgroundColor = UIColor(red: 0.816, green: 0.349, blue: 0.255, alpha: 1)
            audioPlot.color = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            audioPlot.plotType = EZPlotTypeBuffer
            audioPlot.shouldFill = true
            audioPlot.shouldMirror = true
            
            print("outputs: \(EZAudioDevice.outputDevices())")
            Player = EZAudioPlayer(delegate: self)
            Player.shouldLoop = true
            try? session.overrideOutputAudioPort(AVAudioSessionPortOverrideSpeaker)
            if error != nil {
                print("Error overriding output to the speaker: \(error?.localizedDescription ?? "")")
            }
            rollingHistorySlider.value = Float(audioPlot.rollingHistoryLength())
            setupNotifications()
            openFile(withFilePathURL: URL(fileURLWithPath: kAudioFileDefault))
        }
    
    func setupNotifications() {

        NotificationCenter.default.addObserver(self, selector: #selector(self.audioPlayerDidChangeAudioFile(_:)), name:
            NSNotification.Name.EZAudioPlayerDidChangeAudioFile, object: Player)

        NotificationCenter.default.addObserver(self, selector: #selector(self.audioPlayerDidChangeOutputDevice(_:)), name: NSNotification.Name.EZAudioPlayerDidChangeOutputDevice,object: Player)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.audioPlayerDidChangePlayState(_:)), name: NSNotification.Name.EZAudioPlayerDidChangePlayState, object: Player)
    }
func audioPlayerDidChangeAudioFile(_ notification: Notification?) {
        let player = notification?.object as? EZAudioPlayer
        if let aFile = player?.audioFile {
        print("Player changed audio file: \(aFile)")
    }
}
func audioPlayerDidChangeOutputDevice(_ notification: Notification?) {
        let players = notification?.object as? EZAudioPlayer
        if let aDevice = players?.device{
            print("Player changed output device: \(aDevice)")
        }
    }
    
func audioPlayerDidChangePlayState(_ notification: Notification?) {
        let playerr = notification?.object as? EZAudioPlayer
        if let aPlaying = playerr?.isPlaying {
            print(String(format: "Player change play state, isPlaying: %i", aPlaying))
        }
    }
func changePlotType(_ sender: Any?) {
    let selectedSegment: Int? = (sender as? AnyObject as! Int)selectedSegment
        switch selectedSegment {
        case 0?:
            drawBufferPlot()
        case 1?:
            drawRollingPlot()
        default:
            break
        }
    }
    func changeRollingHistoryLength(_ sender: Any?) {
        let value: Float? = (sender as? UISlider)?.value
        audioPlot.rollingHistoryLength = Int(value ?? 0)
        
    }
    
    func changeVolume(_ sender: Any?) {
      //  let value: Float? = (sender as? UISlider)?.value
        Player?.volume = value!
    }
    
    func openFile(withFilePathURL filePathURL: URL?) {
        audioFile = EZAudioFile(url: filePathURL)
        
        filePathLabel.text = filePathURL?.lastPathComponent
        positionSlider.maximumValue = Float(audioFile.totalFrames) as NSNumber
        volumeSlider.value = player.volume()
        
        audioPlot.plotType = EZPlotTypeBuffer
        audioPlot.shouldFill = true
        audioPlot.shouldMirror = true
        weak var weakSelf = self
        audioFile.getWaveformData(withCompletionBlock: { waveformData, length in
            weakSelf.audioPlot.updateBuffer(waveformData?[0], withBufferSize: length)
        })
        player.audioFile = audioFile
    }
    func play(_ sender: Any?) {
        if player.isPlaying() {
            player.pause()
        } else {
            if audioPlot.shouldMirror && (audioPlot.plotType == EZPlotTypeBuffer) {
                audioPlot.shouldMirror = false
                audioPlot.shouldFill = false
            }
            player.play()
        }
    }
    func seek(toFrame sender: Any?) {
        player.seek(toFrame: (sender as? UISlider)?.value as? SInt64)
    }
    func audioPlayer(_ audioPlayer: EZAudioPlayer?, playedAudio buffer: UnsafeMutablePointer<Float>?, withBufferSize bufferSize: UInt32, withNumberOfChannels numberOfChannels: UInt32, in audioFile: EZAudioFile?) {
        weak var weakSelf = self
        DispatchQueue.main.async(execute: {
            weakSelf.audioPlot.updateBuffer(buffer?[0], withBufferSize: bufferSize)
        })
    }
    func audioPlayer(_ audioPlayer: EZAudioPlayer?, updatedPosition framePosition: SInt64, in audioFile: EZAudioFile?) {
        weak var weakSelf = self
        DispatchQueue.main.async(execute: {
            if !weakSelf.positionSlider.isTouchInside {
                weakSelf.positionSlider.value = Float(framePosition)
            }
        })
    }
    func drawBufferPlot() {
        audioPlot.plotType = EZPlotTypeBuffer
        audioPlot.shouldMirror = false
        audioPlot.shouldFill = false
    }
    func drawRollingPlot() {
        audioPlot.plotType = EZPlotTypeRolling
        audioPlot.shouldFill = true
        audioPlot.shouldMirror = true
    }
}


